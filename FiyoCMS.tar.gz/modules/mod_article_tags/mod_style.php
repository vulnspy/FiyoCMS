<?php
/**
* @version		1.5.0
* @package		Article NextPrev
* @copyright	Copyright (C) 2012 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
*/

defined('_FINDEX_') or die('Access Denied');

addCss(FUrl.'modules/mod_article_tags/theme/style.css');