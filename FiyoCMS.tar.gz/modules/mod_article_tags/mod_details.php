<?php
/**
* @version		1.0.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2012 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
*/

$module_desc 		= "Menampilkan artikel tags";

$module_name		= 'Article Tags';
$module_version		= '1.0.0';
$module_date		= '3 January 2014';
$module_author		= 'Fiyo CMS';
$module_author_url	= 'http://www,fiyo.org';