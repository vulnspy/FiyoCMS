<?php
/**
* @version		1.4.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2012 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
*/

	$module_desc 	= "Menampilkan daftar artikel terkait secara acak";

$module_name='Article Related';
$module_version='1.4.0';
$module_date='22 December 2012';
$module_author='Fiyo CMS';
$module_author_url='http://www,fiyo.org';
$module_author_email='info@fiyo.org';