<?php
/**
* @version		1.0.0
* @package		Article NextPrev
* @copyright	Copyright (C) 2012 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
*/

defined('_FINDEX_') or die('Access Denied');

addCss(FUrl.'modules/mod_article_nextprev/theme/style.css');