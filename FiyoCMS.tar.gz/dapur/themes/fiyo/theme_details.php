<?php
/**
* @version		1.5.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2012 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
* @description	
**/

defined('_FINDEX_') or die('Access Denied');

$theme_name			='Admin Panel 2.0';
$theme_version		='1.2.0';
$theme_date			='17 August 2013';
$theme_author		='Fiyo CMS';
$theme_author_url	='http://portofolio.web.id';
$theme_author_email	='firstryan@gmail.com';
$theme_image		='theme_details.jpg';
$theme_docs			='theme_details.jpg';

?>
