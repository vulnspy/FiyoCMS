<?php
/**
* @version		1.5.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2011 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
* @description	
**/

/************** English *************/
@define ('comment_Leave_Comment',"Laisser un commentaire ");
@define ('comment_Send',"Envoyer");
@define ('comment_Reply',"R�pondre");
@define ('comment_Delete',"Supprimer");
@define ('comment_Show',"Show");
@define ('comment_Hide',"Masquer");
@define ('comment_Email',"Email");
@define ('comment_Name',"Nom");
@define ('comment_Website',"Website");
@define ('comment_Comment',"Commentaire");
@define ('comment_Comments',"Commentaires");
@define ('comment_Security_Code',"Code Securit");
@define ('comment_Notice_Error',"S'il vous pla�t remplir les champs obligatoires ( * ) !");
@define ('comment_Notice_Error2',"e-mail est invalide !");
@define ('comment_Notice_Error3',"Le nom que vous utilisez n'est pas autoris� ! ");
@define ('comment_Notice_Error4',"Interdit utilisation interdite mots ! ");
@define ('comment_Notice_Error5',"Code de s�curit� est faux!");
@define ('comment_Notice_Info',"Votre commentaire appara�tra apr�s recharge la page en cours ... ");
@define ('comment_Notice_Info2'," Votre commentaire sera mod�r� avant affichage.");