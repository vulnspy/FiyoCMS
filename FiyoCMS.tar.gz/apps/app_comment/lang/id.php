<?php
/**
* @version		2.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2014 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
* @description	
**/

/************** Bahasa Indonesia *************/
@define ('comment_Leave_Comment',"Beri Komentar");
@define ('comment_Send',"Kirim");
@define ('comment_Reply',"Balas");
@define ('comment_Delete',"Hapus");
@define ('comment_Show',"Tampilkan");
@define ('comment_Hide',"Sembunyikan");
@define ('comment_Name',"Nama");
@define ('comment_Email',"Email");
@define ('comment_Website',"Website");
@define ('comment_Comment',"Komentar");
@define ('comment_Comments',"Komentar");
@define ('comment_Security_Code',"Kode Keamanan");
@define ('comment_Notice_Error',"Mohon isi kolom (*) dengan lengkap dan benar!");
@define ('comment_Notice_Error2',"Email yang digunakan tidak valid!");
@define ('comment_Notice_Error3',"Nama yang digunakan tidak diizinkan!");
@define ('comment_Notice_Error4',"Tidak boleh mengandung kata-kata terlarang!");
@define ('comment_Notice_Error5',"Kode keamanan salah!");
@define ('comment_Notice_Error6',"Komentar anda terlalu singkat.");
@define ('comment_Notice_Info',"Komentar Anda akan ditampilkan setelah muat ulang halaman. Loading...");
@define ('comment_Notice_Info2',"Komentar Anda akan ditampilkan setelah diperiksa.");
@define ('comment_Notice_Info3',"Anda telah berkomentar belum lama ini.");
@define ('leave_a_comment',"Tulis komentar disini...");