<?php
/**
* @version		2.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2014 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
* @description	
**/

/************** English *************/
@define ('_contact_Name',"Nama");
@define ('_contact_Gender',"Kelamin");
@define ('_contact_Man',"Laki-laki");
@define ('_contact_Woman',"Perempuan");
@define ('_contact_Address',"Alamat");
@define ('_contact_Group',"Grup");
@define ('_contact_Link',"Link");
@define ('_contact_Job_Position',"Jabatan");
@define ('_contact_Email',"Email");
@define ('_contact_Phone',"Telepon");
@define ('_contact_About',"Tentang Saya");

@define ('contact_Error',"Mohon lengkapi kolom dengan benar!");
@define ('contact_Error2',"Email yang dimasukan tidak valid!");
@define ('contact_Error3',"Maaf Pesan tidak bisa terkirim.");
@define ('contact_Info',"Pesan berhasil dikirim. Kami akan segera membalas pesan Anda.");
@define ('Message_too_short','Pesan terlalu singkat');
@define ('You_alreay_sent_message','Anda telah mengirimkan pesan belum lama ini');