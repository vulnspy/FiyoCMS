<?php
/**
* @nama			ReCapthca
* @type			Plugin
* @version		1.0.0
* @copyright	Copyright (C) 2012 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
**/

defined('_FINDEX_') or die('Access Denied');

$plg_name = 'ReCapthca';
$plg_desc = 'Plugin reCaptcha';
$plg_author = 'Fiyo CMS';