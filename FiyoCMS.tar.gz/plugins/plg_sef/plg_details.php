<?php
/**
* @nama			SEF
* @type			Plugin
* @version		1.5.0
* @copyright	Copyright (C) 2012 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
**/

defined('_FINDEX_') or die('Access Denied');

$plg_name = 'SEF';
$plg_desc = 'Plugins untuk melakukan kontrol terhadap setiap fungsi SEF';
$plg_author = 'Fiyo CMS';