﻿CKEDITOR.plugins.setLang("fileicon","en",{
  fileicon:
    {
	 toolbar:'Insert File Icon',
	 title:'Insert File Icon'
	}
});