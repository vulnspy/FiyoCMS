<?php
/**
* @version		1.5.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2012 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
* @description	
**/

defined('_FINDEX_') or die('Access Denied');

$theme_name			='BluesTrap';
$theme_version		='1.0';
$theme_date			='6 January 2014';
$theme_author		='First Ryan';
$theme_author_url	='http://firstryan.net/';
$theme_author_email	='firstryan@gmail.com';
$theme_image		='theme_details.jpg';
$theme_logo			='image/logo.png';
?>
